package lambton.agent.secreta;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import lambton.agent.secretaa.R;

public class AddMissionActivity extends AppCompatActivity {
    EditText missionname,date,status;
    MyDatabaseHandler myDatabaseHandler;
    Button save;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_mission);
        myDatabaseHandler=new MyDatabaseHandler(this);
        missionname=(EditText)findViewById(R.id.missionname);
        date=(EditText)findViewById(R.id.date);
        status=(EditText)findViewById(R.id.status);
        save=(Button)findViewById(R.id.save);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            String missionname1=    missionname.getText().toString();
            String date1=    date.getText().toString();
            String status1=    status.getText().toString();
            MissionItem item=new MissionItem();
            item.setMissioncreate(date1);
            item.setMissionname(missionname1);
            item.setStatus(status1);


                if( myDatabaseHandler.saveMission(item)>0)
                {
                    Toast.makeText(AddMissionActivity.this, "Mission Added success", Toast.LENGTH_SHORT).show();
                    finish();

                }
                else
                {
                    Toast.makeText(AddMissionActivity.this, "Try Again", Toast.LENGTH_SHORT).show();

                }
            }
        });

    }
}
