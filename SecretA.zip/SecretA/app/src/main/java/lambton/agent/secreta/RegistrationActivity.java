package lambton.agent.secreta;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;

import lambton.agent.secretaa.R;

public class RegistrationActivity extends AppCompatActivity implements View.OnClickListener {
    EditText name,email, mobile,pass, agency,address,country,website;
    Button save,exit;
    MyDatabaseHandler databaseHandler;
    Context context;
    ImageView imageView;
    private static final int PICK_FROM_GALLERY = 1;
    String imagename="";
    byte imageInByte[];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        context=this;
        databaseHandler=new MyDatabaseHandler(context);

        imageView=(ImageView) findViewById(R.id.image);
        imageView.setOnClickListener(this);

        name=(EditText)findViewById(R.id.name);
        email=(EditText)findViewById(R.id.email);
        mobile=(EditText)findViewById(R.id.mobile);
        pass=(EditText)findViewById(R.id.pass);
        agency=(EditText)findViewById(R.id.agency);
        address=(EditText)findViewById(R.id.address);
        country=(EditText)findViewById(R.id.country);
        website=(EditText)findViewById(R.id.website);
        save=(Button) findViewById(R.id.save);
        exit=(Button) findViewById(R.id.exit);
        save.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        if(view.getId()==R.id.save){
            UserItem userItem=new UserItem();
            userItem.setUserid(databaseHandler.getMaxId());


            userItem.setEmail(email.getText()+"");
            userItem.setName(name.getText()+"");

            userItem.setImageURL(imagename+"");




            userItem.setAgency(agency.getText()+"");
            userItem.setCountry(country.getText()+"");
          long d=  databaseHandler.saveAgent(userItem);
          if(d>0){
              Toast.makeText(context, "Agency added successfully", Toast.LENGTH_SHORT).show();
          }
          else{
              Toast.makeText(context, "Try Again", Toast.LENGTH_SHORT).show();
          }
        }

        else  if(view.getId()==R.id.image)
        {
            callGallery();
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (resultCode != RESULT_OK)
            return;

        switch (requestCode) {

            case PICK_FROM_GALLERY:
                Bundle extras2 = data.getExtras();
                Uri selectedImage = data.getData();
                System.out.println("picture selectedImage "+selectedImage);
                imagename=selectedImage.toString();
                try {
                    Bitmap bitmap = Utils.decodeUri(RegistrationActivity.this,
                            selectedImage, 200);// call
                    if(bitmap!=null){
                        System.out.println("bitmap = " + bitmap);
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        bitmap.compress(Bitmap.CompressFormat.PNG, 80, stream);
                        imageInByte = stream.toByteArray();
                        System.out.println("gallery imageInByte = " + imageInByte);
                        imageView.setImageBitmap(bitmap);

                    }
                    else {
                        System.out.println("bitmap = " + bitmap);
                    }
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }




                break;
        }
    }
    public void callGallery() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        intent.putExtra("crop", "true");
        intent.putExtra("aspectX", 0);
        intent.putExtra("aspectY", 0);
        intent.putExtra("outputX", 200);
        intent.putExtra("outputY", 150);
        intent.putExtra("return-data", true);
        startActivityForResult(
                Intent.createChooser(intent, "Complete action using"),
                PICK_FROM_GALLERY);

    }
}
