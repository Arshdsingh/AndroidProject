package lambton.agent.secreta;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.LinkedList;

import lambton.agent.secretaa.R;

public class MissionAdapter extends BaseAdapter {
    Context context;
    LinkedList<MissionItem> listArrayList;
    // Uri for image path
    private static Uri imageUri = null;


    public MissionAdapter(Context context, LinkedList<MissionItem> listArrayList){
        this.context=context;
        this.listArrayList=listArrayList;
    }
    @Override
    public int getCount() {
        return listArrayList.size();
    }

    @Override
    public Object getItem(int i) {
        return listArrayList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(final  int i, View view, ViewGroup viewGroup) {
        imageUri = null;
        View v= LayoutInflater.from(context).inflate(R.layout.itemlayout,viewGroup,false);
        LinearLayout layout0=(LinearLayout) v.findViewById(R.id.layout0);
        final TextView missionname=(TextView)v.findViewById(R.id.missionname);
        TextView date=(TextView)v.findViewById(R.id.date);
        TextView status=(TextView)v.findViewById(R.id.status);
        missionname.setText("Mission Name : "+listArrayList.get(i).getMissionname());
        date.setText("Mission Date : "+listArrayList.get(i).getMissioncreate());
        status.setText("Mission Status : "+listArrayList.get(i).getStatus());
        layout0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(context,MissionUpdateActivity.class);
                intent.putExtra("missionname",listArrayList.get(i).getMissionname());
                intent.putExtra("date",listArrayList.get(i).getMissioncreate());
                intent.putExtra("status",listArrayList.get(i).getStatus());
                context.startActivity(intent);
                ((Activity)context).finish();
            }
        });
        return v;
    }

}
