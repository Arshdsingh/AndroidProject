package lambton.agent.secreta;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import lambton.agent.secretaa.R;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
LinearLayout agentadd,agentsearch,agentlist;
Button add,list,search;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        add=(Button)findViewById(R.id.add);
        search=(Button)findViewById(R.id.search);
        list=(Button)findViewById(R.id.list);
        add.setOnClickListener(this);
        search.setOnClickListener(this);
        list.setOnClickListener(this);
        agentadd=(LinearLayout)findViewById(R.id.agentadd);
        agentsearch=(LinearLayout)findViewById(R.id.agentsearch);
        agentlist=(LinearLayout)findViewById(R.id.agentlist);
        agentadd.setOnClickListener(this);
        agentsearch.setOnClickListener(this);
        agentlist.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId()==R.id.agentadd){
            Intent intent=new Intent(MainActivity.this,RegistrationActivity.class);
            startActivity(intent);
        }
        else  if (view.getId()==R.id.agentlist){
            Intent intent=new Intent(MainActivity.this,AgentListActivity.class);
            startActivity(intent);
        }
        else  if (view.getId()==R.id.agentsearch){
            Intent intent=new Intent(MainActivity.this,AgentSearchActvitiy.class);
            startActivity(intent);
        }
        else if (view.getId()==R.id.add){
            Intent intent=new Intent(MainActivity.this,RegistrationActivity.class);
            startActivity(intent);
        }
        else  if (view.getId()==R.id.list){
            Intent intent=new Intent(MainActivity.this,AgentListActivity.class);
            startActivity(intent);
        }
        else  if (view.getId()==R.id.search){
            Intent intent=new Intent(MainActivity.this,AgentSearchActvitiy.class);
            startActivity(intent);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.viewmission)
        {
            Intent intent=new Intent(MainActivity.this,MissionListActivity.class);
            startActivity(intent);
        } else if(item.getItemId()==R.id.addmission)
        {
            Intent intent=new Intent(MainActivity.this,AddMissionActivity.class);
            startActivity(intent);
        } else if(item.getItemId()==R.id.updatemission)
        {
            Intent intent=new Intent(MainActivity.this,MissionUpdateActivity.class);
            startActivity(intent);
        }
        return true;
    }
}
