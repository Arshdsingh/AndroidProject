package lambton.agent.secreta;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.LinkedList;

import lambton.agent.secretaa.R;

public class MissionListActivity extends AppCompatActivity {
    ListView listView;
    LinkedList<MissionItem> linkedList;
    MyDatabaseHandler myDatabaseHandler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mission_list);
        listView=(ListView)findViewById(R.id.listView);
        linkedList=new   LinkedList<MissionItem> ();
        myDatabaseHandler=new MyDatabaseHandler(this);

        linkedList=myDatabaseHandler.getMissionList();
        listView.setAdapter(new MissionAdapter(MissionListActivity.this,linkedList));

    }
}
