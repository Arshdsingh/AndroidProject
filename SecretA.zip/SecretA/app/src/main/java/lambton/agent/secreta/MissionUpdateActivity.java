package lambton.agent.secreta;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import lambton.agent.secretaa.R;

public class MissionUpdateActivity extends AppCompatActivity {
    EditText missionname,date,status;
    MyDatabaseHandler myDatabaseHandler;
    Button save;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mission_update);
        myDatabaseHandler=new MyDatabaseHandler(this);
        missionname=(EditText)findViewById(R.id.missionname);
        date=(EditText)findViewById(R.id.date);
        status=(EditText)findViewById(R.id.status);
        save=(Button)findViewById(R.id.save);
        if(getIntent().getStringExtra("missionname")!=null
         &&  getIntent().getStringExtra("status")!=null
         &&  getIntent().getStringExtra("date")!=null
        ){
            missionname.setText(""+getIntent().getStringExtra("missionname"));
            date.setText(""+getIntent().getStringExtra("date"));
            status.setText(""+getIntent().getStringExtra("status"));
            missionname.setEnabled(false);
        }
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String missionname1=    missionname.getText().toString();
                String date1=    date.getText().toString();
                String status1=    status.getText().toString();
                MissionItem item=new MissionItem();
                item.setMissioncreate(date1);
                item.setMissionname(missionname1);
                item.setStatus(status1);
               if( myDatabaseHandler.updateMission(item,missionname1)>0)
               {
                   Toast.makeText(MissionUpdateActivity.this, "Updated success", Toast.LENGTH_SHORT).show();
                   finish();

               }
               else
               {
                   Toast.makeText(MissionUpdateActivity.this, "Try Again", Toast.LENGTH_SHORT).show();

               }
            }
        });
    }
}
