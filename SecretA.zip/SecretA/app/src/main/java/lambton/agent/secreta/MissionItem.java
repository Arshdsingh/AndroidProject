package lambton.agent.secreta;

import java.io.Serializable;

public class MissionItem implements Serializable {
    String id;
    String missionname ,missioncreate ,status ;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMissionname() {
        return missionname;
    }

    public void setMissionname(String missionname) {
        this.missionname = missionname;
    }

    public String getMissioncreate() {
        return missioncreate;
    }

    public void setMissioncreate(String missioncreate) {
        this.missioncreate = missioncreate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
