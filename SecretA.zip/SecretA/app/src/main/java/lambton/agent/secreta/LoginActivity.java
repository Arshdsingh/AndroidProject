package lambton.agent.secreta;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import lambton.agent.secretaa.R;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{
    EditText name,pass;
    TextView register;
    Button exit,save;
    int count=0;
    MyDatabaseHandler databaseHandler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        databaseHandler=new MyDatabaseHandler(this);
        register=(TextView)findViewById(R.id.register);
        name=(EditText) findViewById(R.id.user);
        pass=(EditText) findViewById(R.id.pass);
        exit=(Button) findViewById(R.id.exit);
        save=(Button) findViewById(R.id.save);
        exit.setOnClickListener(this);
        save.setOnClickListener(this);
        register.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                Intent intent=new Intent(LoginActivity.this,RegistrationActivity.class);
                startActivity(intent);

                return true;
            }
        });
    }

    @Override
    public void onClick(View view) {
        if (view.getId()==R.id.save)
        {
                    boolean flag= databaseHandler.checkLogin(name.getText().toString(),pass.getText().toString());
                    if(flag){
                        Intent intent=new Intent(LoginActivity.this,MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                    else {
                        if(++count<=3)
                        Toast.makeText(this, "Incorrect Username ,"+(3-count)+" Try Left", Toast.LENGTH_SHORT).show();
                        else
                            finish();
                    }
        }
        else  if (view.getId()==R.id.exit) {
            finish();
        }
    }
}
