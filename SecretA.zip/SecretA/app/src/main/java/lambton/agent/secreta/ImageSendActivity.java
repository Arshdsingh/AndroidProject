package lambton.agent.secreta;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.Serializable;

import lambton.agent.secretaa.R;

public class ImageSendActivity extends AppCompatActivity implements View.OnClickListener {
ImageView imageView;

Button share;
    private static final int PICK_FROM_GALLERY = 1;
    Uri imagename=null;
    byte imageInByte[];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_send);
        imageView=(ImageView)findViewById(R.id.imageview);
        imageView.setOnClickListener(this);
        share=(Button) findViewById(R.id.share);
        share.setOnClickListener(this);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (resultCode != RESULT_OK)
            return;

        switch (requestCode) {

            case PICK_FROM_GALLERY:
                Bundle extras2 = data.getExtras();
                Uri selectedImage = data.getData();
                System.out.println("picture selectedImage "+selectedImage);
                imagename=selectedImage;
                try {
                    Bitmap bitmap = Utils.decodeUri(ImageSendActivity.this,
                            selectedImage, 200);// call
                    if(bitmap!=null){
                        System.out.println("bitmap = " + bitmap);
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        bitmap.compress(Bitmap.CompressFormat.PNG, 80, stream);
                        imageInByte = stream.toByteArray();
                        System.out.println("gallery imageInByte = " + imageInByte);
                        imageView.setImageBitmap(bitmap);

                    }
                    else {
                        System.out.println("bitmap = " + bitmap);
                    }
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }




                break;
        }
    }
    public void callGallery() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        intent.putExtra("crop", "true");
        intent.putExtra("aspectX", 0);
        intent.putExtra("aspectY", 0);
        intent.putExtra("outputX", 200);
        intent.putExtra("outputY", 150);
        intent.putExtra("return-data", true);
        startActivityForResult(
                Intent.createChooser(intent, "Complete action using"),
                PICK_FROM_GALLERY);

    }

    @Override
    public void onClick(View view) {
        if (view.getId()==R.id.imageview){
            callGallery();
        }
        else if(view.getId()==R.id.share)
        {
            shareImage(imagename);

        }
    }
    // Share image
    private void shareImage(Uri imagePath) {
        Intent sharingIntent = new Intent(Intent.ACTION_SEND);
        sharingIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
        sharingIntent.setType("image/*");
        sharingIntent.putExtra(Intent.EXTRA_STREAM, imagePath);
        startActivity(Intent.createChooser(sharingIntent, "Share Image Using"));
    }
}
