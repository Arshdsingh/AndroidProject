package lambton.agent.secreta;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.LinkedList;

import lambton.agent.secretaa.R;

public class AgentSearchActvitiy extends AppCompatActivity implements View.OnClickListener {
    ListView listView;
    LinkedList<UserItem> linkedList;
    MyDatabaseHandler myDatabaseHandler;
    EditText keywords;
    ImageView search;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent_search_actvitiy);
        listView=(ListView)findViewById(R.id.listView);
        search=(ImageView) findViewById(R.id.search1);
        keywords=(EditText) findViewById(R.id.keywords);
        linkedList=new   LinkedList<UserItem> ();
        myDatabaseHandler=new MyDatabaseHandler(this);

        linkedList=myDatabaseHandler.getAgentList();
        listView.setAdapter(new ListAdapter(AgentSearchActvitiy.this,linkedList));
        search.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        if(view.getId()==R.id.search1)
        {

            if(keywords!=null){
            if(keywords.getText().toString().length()>0) {
                Toast.makeText(this, "Loading", Toast.LENGTH_SHORT).show();

                linkedList = myDatabaseHandler.getAgentListSearch(keywords.getText().toString());
                listView.setAdapter(new ListAdapter(AgentSearchActvitiy.this, linkedList));
            }

        }
        else {
            Toast.makeText(this, "Empty", Toast.LENGTH_SHORT).show();
            linkedList=myDatabaseHandler.getAgentList();
            listView.setAdapter(new ListAdapter(AgentSearchActvitiy.this,linkedList));
        }
        }
    }
}
