package lambton.agent.secreta;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.LinkedList;

public class MyDatabaseHandler extends SQLiteOpenHelper {
    String table1="create table products (prodid integer primary key autoincrement, prodnamename varchar(150), proddesc varchar(250), prodprice varchar(250))";
    String table2="create table mission (id integer primary key autoincrement,missionname varchar(150) ,missioncreate date , status varchar(150))";
    String table3="create table missionhistory (id integer primary key autoincrement,missionid integer ,updated date , message varchar(150),imageurl varchar(255),fromuserid integer, touserid integer)";
    Context context;
    public MyDatabaseHandler(Context context)
    {
        super(context,"userdb",null,1);
        this.context=context;
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        sqLiteDatabase.execSQL(table1);
        sqLiteDatabase.execSQL(table2);
        sqLiteDatabase.execSQL(table3);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
    sqLiteDatabase.execSQL("drop table if exists secretagent");
    onCreate(sqLiteDatabase);
    }
    public long saveAgent(UserItem user){
        SQLiteDatabase database=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        System.out.println("email = " + user.getEmail());
        System.out.println("imagename = " + user.getImageURL());
        if(user!=null) {
            contentValues.put("name", user.getName() + "");
            contentValues.put("email", user.getEmail() + "");
            contentValues.put("mobile", user.getMobile() + "");
            contentValues.put("country", user.getCountry() + "");
            contentValues.put("agency", user.getAgency() + "");
            contentValues.put("address", user.getAddress() + "");
            contentValues.put("website", user.getWebsite() + "");
            contentValues.put("password", user.getPassword() + "");
            contentValues.put("image", user.getImageitem() + "");
            contentValues.put("imagename", user.getImageURL() + "");
            return      database.insert("secretagent",null,contentValues);
        }
        else {
            return 0;
        }

    }

    public long saveMission(MissionItem missionItem){
        SQLiteDatabase database=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        if(missionItem!=null) {
            contentValues.put("missionname", missionItem.getMissionname() + "");
            contentValues.put("missioncreate", missionItem.getMissioncreate() + "");
            contentValues.put("status", missionItem.getStatus() + "");

            return      database.insert("mission",null,contentValues);
        }
        else {
            return 0;
        }

    }
    public long updateMission(MissionItem missionItem,String missionname){
        SQLiteDatabase database=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        if(missionItem!=null) {
            contentValues.put("missionname", missionItem.getMissionname() + "");
            contentValues.put("missioncreate", missionItem.getMissioncreate() + "");
            contentValues.put("status", missionItem.getStatus() + "");

            return      database.update("mission",contentValues,"missionname = ? ",new String[]{missionname});
        }
        else {
            return 0;
        }

    }
    LinkedList<UserItem> userItems=new LinkedList<>();

    public  LinkedList<UserItem> getAgentList(){
        userItems=new LinkedList<>();
        SQLiteDatabase database=this.getReadableDatabase();
        Cursor cursor=database.query("secretagent",new String[]{"userid","name","image","imagename","email","mobile","country","agency","website","address"},null,null,null,null,null,null);
        int dbid=0;
        String databaseuser="",dbimagename="",email="",mobile="",agency="",website="",country="",address="";
                byte []databaimageitem=null;
       if (cursor!=null) {
           while (cursor.moveToNext()) {
               dbid = cursor.getInt(cursor.getColumnIndex("userid"));
               databaseuser = cursor.getString(cursor.getColumnIndex("name"));
               agency = cursor.getString(cursor.getColumnIndex("agency"));
               address = cursor.getString(cursor.getColumnIndex("address"));
               website = cursor.getString(cursor.getColumnIndex("website"));
               country = cursor.getString(cursor.getColumnIndex("country"));
               dbimagename = cursor.getString(cursor.getColumnIndex("imagename"));
               email = cursor.getString(cursor.getColumnIndex("email"));
               mobile = cursor.getString(cursor.getColumnIndex("mobile"));
               databaimageitem = cursor.getBlob(cursor.getColumnIndex("image"));
               System.out.println("databaimageitem = " + dbimagename);
               UserItem userItem=new UserItem();
               userItem.setUserid(dbid);
               userItem.setEmail(email);
               userItem.setName(databaseuser);
               userItem.setAgency(agency);
               userItem.setAddress(address);
               userItem.setCountry(country);
               userItem.setWebsite(website);
               userItem.setName(databaseuser);
               userItem.setImageitem(databaimageitem);
               userItem.setMobile(mobile);
               userItem.setImageURL(dbimagename);
               userItems.add(userItem);
           }
           return userItems;

           // Toast.makeText(context, "Fetch Success", Toast.LENGTH_SHORT).show();

       }
       else {
           Toast.makeText(context, "Stack Empty ", Toast.LENGTH_SHORT).show();
       }
       return  null;
    }
    LinkedList<MissionItem> missionItems=new LinkedList<>();

    public  LinkedList<MissionItem> getMissionList(){

        missionItems=new LinkedList<>();
        SQLiteDatabase database=this.getReadableDatabase();
        Cursor cursor=database.query("mission",new String[]{"id","missionname","missioncreate","status"},null,null,null,null,null,null);
        int dbid=0;
        String missionname="",missioncreate="",status="";
        if (cursor!=null) {
            while (cursor.moveToNext()) {
                dbid = cursor.getInt(cursor.getColumnIndex("id"));
                missionname = cursor.getString(cursor.getColumnIndex("missionname"));
                missioncreate = cursor.getString(cursor.getColumnIndex("missioncreate"));
                status = cursor.getString(cursor.getColumnIndex("status"));

                MissionItem missionItem=new MissionItem();
                missionItem.setMissionname(missionname);
                missionItem.setStatus(status);
                missionItem.setMissioncreate(missioncreate);

                missionItems.add(missionItem);
            }
            return missionItems;

            // Toast.makeText(context, "Fetch Success", Toast.LENGTH_SHORT).show();

        }
        else {
            Toast.makeText(context, "Stack Empty ", Toast.LENGTH_SHORT).show();
        }
        return  null;
    }
    public  LinkedList<UserItem> getAgentListSearch(String keywords){
        userItems=new LinkedList<>();
        SQLiteDatabase database=this.getReadableDatabase();
        //Cursor cursor=database.query("secretagent",new String[]{"userid","name","image","imagename","email","mobile","country","agency","website","address"},"mobile like '%?%' or email like '%?%' or city like '%?%' or address like '%?%' or name like '%?%' ",new String[]{keywords,keywords,keywords,keywords,keywords},null,null,null,null);
        Cursor cursor=database.query("secretagent",new String[]{"userid","name","image","imagename","email","mobile","country","agency","website","address"},"mobile = ?  ",new String[]{keywords},null,null,null,null);
        int dbid=0;
        String databaseuser="",dbimagename="",email="",mobile="",agency="",website="",country="",address="";
        byte []databaimageitem=null;
        if (cursor!=null) {
            while (cursor.moveToNext()) {
                dbid = cursor.getInt(cursor.getColumnIndex("userid"));
                databaseuser = cursor.getString(cursor.getColumnIndex("name"));
                agency = cursor.getString(cursor.getColumnIndex("agency"));
                country = cursor.getString(cursor.getColumnIndex("country"));
                dbimagename = cursor.getString(cursor.getColumnIndex("imagename"));
                email = cursor.getString(cursor.getColumnIndex("email"));
                System.out.println("databaimageitem = " + dbimagename);
                UserItem userItem=new UserItem();
                userItem.setUserid(dbid);
                userItem.setEmail(email);
                userItem.setName(databaseuser);
                userItem.setAgency(agency);

                userItem.setCountry(country);


                userItem.setImageitem(databaimageitem);

                userItem.setImageURL(dbimagename);
                userItems.add(userItem);
            }
            // Toast.makeText(context, "Fetch Success", Toast.LENGTH_SHORT).show();

        }
        return userItems;
    }

    public  UserItem getAgentDetail(String username, String password){
        UserItem userItem=new UserItem();
        SQLiteDatabase database=this.getReadableDatabase();
        Cursor cursor=database.query("secretagent",new String[]{"userid","name","image","imagename","email","mobile"},"(mobile = ? or email=?) and password=?",new String[]{username,username,password},null,null,null,null);
        int dbid=0;
        String databaseuser="",dbimagename="",email="",mobile="",agency="",website="",country="",address="";
        byte []databaimageitem=null;
        if (cursor!=null) {
            if (cursor.moveToNext()) {
                userItem=new UserItem();
                dbid = cursor.getInt(cursor.getColumnIndex("userid"));
                databaseuser = cursor.getString(cursor.getColumnIndex("name"));
                dbimagename = cursor.getString(cursor.getColumnIndex("imagename"));
                email = cursor.getString(cursor.getColumnIndex("email"));
                mobile = cursor.getString(cursor.getColumnIndex("mobile"));
                agency = cursor.getString(cursor.getColumnIndex("agency"));
                country = cursor.getString(cursor.getColumnIndex("country"));
                address = cursor.getString(cursor.getColumnIndex("address"));
                website = cursor.getString(cursor.getColumnIndex("website"));
                databaimageitem = cursor.getBlob(cursor.getColumnIndex("image"));
                System.out.println("databaimageitem = " + dbimagename);
                userItem.setUserid(dbid);
                userItem.setEmail(email);
                userItem.setName(databaseuser);
                userItem.setMobile(mobile);
                userItem.setImageitem(databaimageitem);
                userItem.setImageURL(dbimagename);
                userItem.setAgency(agency);
                userItem.setAddress(address);
                userItem.setCountry(country);
                userItem.setWebsite(website);
                return userItem;
            }
            //Toast.makeText(context, "Fetch Success", Toast.LENGTH_SHORT).show();

        }
        return null;
    }
    public  boolean checkLogin(String username, String password){
        SQLiteDatabase database=this.getReadableDatabase();
        Cursor cursor=database.query("secretagent",new String[]{"userid","name","image","imagename","email","mobile"},"(mobile = ? or email=?) and password=?",new String[]{username,username,password},null,null,null,null);
        if (cursor!=null) {
            if (cursor.moveToNext()) {
                return true;
            }

        }
        return false;
    }
    public  int getMaxId(){
        userItems=new LinkedList<>();
        SQLiteDatabase database=this.getReadableDatabase();
        Cursor cursor=database.query("secretagent",new String[]{"userid","name","image","imagename"},null,null,null,null,"userid desc",null);
        int dbid=0;

        if (cursor!=null) {
            if (cursor.moveToNext()) {
                dbid = cursor.getInt(cursor.getColumnIndex("userid"));
                return dbid;
            }

        }
        return 1;
    }
}
