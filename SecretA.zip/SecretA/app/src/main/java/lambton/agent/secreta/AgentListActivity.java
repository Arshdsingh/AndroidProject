package lambton.agent.secreta;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import android.widget.Toast;

import java.util.LinkedList;

import lambton.agent.secretaa.R;

public class AgentListActivity extends AppCompatActivity {
    ListView listView;
    LinkedList<UserItem> linkedList;
    MyDatabaseHandler myDatabaseHandler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent_list);
        listView=(ListView)findViewById(R.id.listView);
        linkedList=new   LinkedList<UserItem> ();
        myDatabaseHandler=new MyDatabaseHandler(this);

            linkedList=myDatabaseHandler.getAgentList();
            listView.setAdapter(new ListAdapter(AgentListActivity.this,linkedList));

    }
}
