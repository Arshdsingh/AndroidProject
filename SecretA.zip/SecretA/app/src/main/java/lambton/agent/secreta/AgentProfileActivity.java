package lambton.agent.secreta;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import lambton.agent.secretaa.R;

public class AgentProfileActivity extends AppCompatActivity implements View.OnClickListener{
    TextView name,email, mobile,pass, agency,address,country,website;
    MyRoundedImageView websiteicon,aboout,call,map,sms,camera;
    UserItem userItem=null;
    public static final int NOTIFICATION_ID = 1;
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS =0 ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent_profile);
        name=(TextView)findViewById(R.id.name);
        email=(TextView)findViewById(R.id.email);
        mobile=(TextView)findViewById(R.id.mobile);
        pass=(TextView)findViewById(R.id.pass);

        agency=(TextView)findViewById(R.id.agency);
        address=(TextView)findViewById(R.id.address);
        country=(TextView)findViewById(R.id.country);
        website=(TextView)findViewById(R.id.website);
        websiteicon=(MyRoundedImageView)findViewById(R.id.websiteicon);
        aboout=(MyRoundedImageView)findViewById(R.id.about);
        call=(MyRoundedImageView)findViewById(R.id.call);
        camera=(MyRoundedImageView)findViewById(R.id.camera);
        map=(MyRoundedImageView)findViewById(R.id.map);
        sms=(MyRoundedImageView)findViewById(R.id.sms);
        websiteicon.setOnClickListener(this);
        aboout.setOnClickListener(this);
        call.setOnClickListener(this);
        camera.setOnClickListener(this);
        map.setOnClickListener(this);
        sms.setOnClickListener(this);


        if(getIntent().getSerializableExtra("userdata")!=null)
        {
            userItem=(UserItem)getIntent().getSerializableExtra("userdata");
            if(userItem!=null)
            {
                name.setText("Name : "+userItem.getName());
                System.out.println("listArrayList.get(i).getUrl() = " + userItem.getImageURL());
                mobile.setText("Mobile : "+userItem.getMobile());
                agency.setText("Agency : "+userItem.getAgency());
                website.setText("Website : "+userItem.getWebsite());
                country.setText("Country : "+userItem.getCountry());
                address.setText("Address : "+userItem.getAddress());
                email.setText("Email : "+userItem.getEmail());
            }
            else{
                Toast.makeText(this, "Empty", Toast.LENGTH_SHORT).show();
            }
        }

    }
    String m_Text = "";

    @Override
    public void onClick(View view) {
        Intent intent=null;
        switch (view.getId())
        {
            case R.id.about:
                 intent=new Intent(AgentProfileActivity.this,MissionListActivity.class);
                startActivity(intent);
                break;

                case R.id.call:


                     intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + userItem.getMobile()));
                    startActivity(intent);
                break;

                case R.id.sms:

                    sendSMSMessage();

                    break;

                case R.id.websiteicon:
                    String url = userItem.getWebsite()+"";
                     intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse(url));
                    startActivity(intent);
                break;

                case R.id.map:

                     intent = new Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q="+userItem.getAddress()));
                    intent.setPackage("com.google.android.apps.maps");
                    startActivity(intent);
                break;

                case R.id.camera:
                    intent=new Intent(AgentProfileActivity.this,ImageSendActivity.class);
                    startActivity(intent);
                break;
        }
    }
    protected void sendSMSMessage() {


        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.SEND_SMS)) {
                android.app.AlertDialog.Builder alert = new android.app.AlertDialog.Builder(AgentProfileActivity.this);
                alert.setMessage("Kindly allow permission");
                alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        ActivityCompat.requestPermissions(AgentProfileActivity.this, new String[]{Manifest.permission.SEND_SMS}, MY_PERMISSIONS_REQUEST_SEND_SMS);
                    }
                });

                android.app.AlertDialog dialog = alert.create();
                dialog.show();
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        MY_PERMISSIONS_REQUEST_SEND_SMS);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_SEND_SMS: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    sendMessage();
                } else {
                    Toast.makeText(getApplicationContext(),
                            "SMS faild, please try again.", Toast.LENGTH_LONG).show();
                    return;
                }
            }
        }

    }
    public void sendMessage()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Send SMS");

// Set up the input
        final EditText input = new EditText(this);
// Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        builder.setView(input);

// Set up the buttons
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                m_Text = input.getText().toString();
                try {

                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(userItem.getMobile(), null, m_Text, null, null);
                    Toast.makeText(getApplicationContext(), "SMS sent.",
                            Toast.LENGTH_LONG).show();

                } catch(Exception e) {
                    e.printStackTrace();
                }
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();


    }
}
