package com.example.arshdeep.store;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    EditText editemail,editpasssword;
    DBHelper dbHelper = new DBHelper(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editemail = (EditText) findViewById(R.id.loginemail);
        editpasssword = (EditText) findViewById(R.id.loginpassword);
    }
    public void onLogin(View view ) {
        SQLiteDatabase sqLiteDatabase = dbHelper.getReadableDatabase();
        String query = "SELECT * FROM USER WHERE EMAIL = ? AND PASSWORD = ?";

        Cursor cursor = sqLiteDatabase.rawQuery(query,new String[]{
                editemail.getText().toString(),
                editpasssword.getText().toString()
        });
        boolean isSuccessful = false;
        if (!cursor.isAfterLast())
            isSuccessful = true;
        else
            Toast.makeText(this,"Wrong Username Or Password",Toast.LENGTH_SHORT).show();

        if (isSuccessful) {
            Intent intent = new Intent(this,HomeActivity.class);
            startActivity(intent);
            Toast.makeText(this,"Login Successful",Toast.LENGTH_SHORT).show();
            finish();
        }
    }
    public void onLoginRegister(View view) {
        Intent intent = new Intent(this,RegisterActivity.class);
        startActivity(intent);
    }
}

