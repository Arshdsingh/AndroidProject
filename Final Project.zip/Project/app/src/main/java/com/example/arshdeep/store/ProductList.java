package com.example.arshdeep.store;

import android.app.Application;

import java.util.ArrayList;

public class ProductList {
    public static ArrayList<ListActivityModel> getArratList() {
        ArrayList<ListActivityModel> arraylist = new ArrayList<>();
        ListActivityModel listActivityModel = null;


        listActivityModel = new ListActivityModel();
        listActivityModel.setProductimage(R.drawable.macbookpro);
        listActivityModel.setProductid(1);
        listActivityModel.setProductname("Apple Macbook Pro");
        listActivityModel.setPriductprice("2000");
        listActivityModel.setProductdesc("It's razor thin, feather light, and even faster and more powerful than before. It has the brightest, most colorful Mac notebook display ever. And it features the Touch Bar - a Multi-Touch enabled strip of glass built into the keyboard for instant access to the tools you want, right when you want them. MacBook Pro is built on groundbreaking ideas. And it's ready for yours.");
        arraylist.add(listActivityModel);


        listActivityModel = new ListActivityModel();
        listActivityModel.setProductid(2);
        listActivityModel.setProductimage(R.drawable.iphone);
        listActivityModel.setProductname("Apple Iphone 8");
        listActivityModel.setPriductprice("1300");
        listActivityModel.setProductdesc("This update to the iPhone Series features an improved camera, processor, and battery, Plus it's water-resistant. Other features are similar, including a pressure-sensitive screen with haptic feedback, rounded metal design, NFC, fingerprint reader, Siri voice assistant, and front camera.");
        arraylist.add(listActivityModel);

        listActivityModel = new ListActivityModel();
        listActivityModel.setProductid(3);
        listActivityModel.setProductimage(R.drawable.macbookair);
        listActivityModel.setProductname("Apple Macbook Air");
        listActivityModel.setPriductprice("1400");
        listActivityModel.setProductdesc("1.8 - 2.9 GHz Intel Core i5 Dual-Core Processor 8GB DDR3 RAM / 128GB SSD Integrated Intel HD Graphics 6000 macOS Sierra");
        arraylist.add(listActivityModel);

        listActivityModel = new ListActivityModel();
        listActivityModel.setProductid(4);
        listActivityModel.setProductimage(R.drawable.jblcharge);
        listActivityModel.setProductname("JBL Charge 2+");
        listActivityModel.setPriductprice("1000");
        listActivityModel.setProductdesc("Listen wirelessly. Charge endlessly.The Renewed JBL charge 2 plus is an ultra-powerful, ultra-big-battery portable Bluetooth speaker with high-quality stereo sound. Revamped with fresh styles and a splashproof design, the charge 2 plus takes the party everywhere – be it poolside or dancing in the rain – and amplifies the excitement with JBL bass radiators. The speaker is powered by a 6000mah battery that provides an incredible 12 hours of playtime and can charge all your devices, like your smartphone or tablet, via USB. Charge 2 plus also comes with a built-in noise and echo cancelling speakerphone so you make crystal clear calls with the press of a button. Trade off as DJs with your friends to share everyone’s favorite tunes with social mode by connecting up to 3 music sources to the speaker and taking turns playing music.");
        arraylist.add(listActivityModel);

        listActivityModel = new ListActivityModel();
        listActivityModel.setProductid(5);
        listActivityModel.setProductimage(R.drawable.powerbank);
        listActivityModel.setProductname("Power Bank");
        listActivityModel.setPriductprice("25");
        listActivityModel.setProductdesc(" Faster and safer charging with our advanced technology 10 million happy users and counting.Industry leading output of 4.8 amps provides enough power to simultaneously charge any combination of devices at full speed.");
        arraylist.add(listActivityModel);


        return arraylist;
    }
}
