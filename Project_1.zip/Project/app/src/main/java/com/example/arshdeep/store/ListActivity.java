package com.example.arshdeep.store;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toolbar;


public class ListActivity extends AppCompatActivity {
    ListView listView;
    String products[] = new String[]
            {"Apple Macbook Pro","Iphone 8","Apple Macbook Air","Samsung s9",
                    "Jbl Charge 2+","Power Bank"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        listView = (ListView) findViewById(R.id.itemlistview);
        ArrayAdapter arrayAdapter = new ArrayAdapter(ListActivity.this,android.R.layout.simple_expandable_list_item_1,products);
        listView.setAdapter(arrayAdapter);

    }
}
